/*
Nombre: Diego Gallo

 1) Teoria
 	a) Definir con tus palabras que es una variable
 		Es un parcion de memoria que se utiliza para almacenar un valor
 	b) Definir con tus palabras que es una iteracion. Y que diferencia hay entre un ciclo while y un do-while
 		Una iteracion es un ciclo que se repite. Puede ser indefinidamente o hasta que se cumpla una condicion.
 		La diferencia entre while y do-while es el momento en que se realiza la evaluacion de la condicion que corte
 	c) Que es un contador y para que sirve?
 		Un contador es una variable que nos permite contar valores. Por ejemplo, en un ciclo do-while se puede ir incrementando en 1 cada 
		iteracion para conocer la cantidad de veces que se ejecuta el ciclo.
 	d) Definir con tus palabras que es un array.
 		Es una porcion de memoria en la que se almacenan n cantidad de valores. Es como una coleccion de variables de un mismo tipo.

 2) Desarrollar un programa que solicite al usuario la carga de un array de 5 elementos.
 	a) Ordenarlos en forma descendiente
 	b) Mostrar el array desordenado inicial y el array ordenado.
 	
 3) Desarrollar un programa que le solicity un set de calificacion al usuario.
 	a) El usuario puede ingresar cualquier cantidad de calificaciones
 	b) El usuario debe ingresar una calificacion del 1 al 10, de lo contrario, desestimar calificacion
 	c) Dejar de solicitar calificacion cuando el usuario ingrese "0"
 	d) El usuario no ingresara numeros negativos
 	e) Mostrar el promedio de las calificaciones ingresadas
 	f) Mostrar la cantidad de notas ingresadas
*/
